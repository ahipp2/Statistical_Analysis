# PID of current job: 60033
mSet<-InitDataObjects("conc", "stat", FALSE)
mSet<-Read.TextData(mSet, "Replacing_with_your_file_path", "colu", "disc");
mSet<-SanityCheckData(mSet)
mSet<-ContainMissing(mSet)
mSet<-ReplaceMin(mSet);
mSet<-PreparePrenormData(mSet)
mSet<-Normalization(mSet, "NULL", "NULL", "AutoNorm", ratio=FALSE, ratioNum=20)
mSet<-PlotNormSummary(mSet, "norm_1_", "png", 72, width=NA)
mSet<-PlotSampleNormSummary(mSet, "snorm_1_", "png", 72, width=NA)
mSet<-FC.Anal(mSet, 2.0, 0, FALSE)
mSet<-PlotFC(mSet, "fc_1_", "png", 72, width=NA)
mSet<-FC.Anal(mSet, 2.0, 0, FALSE)
mSet<-PlotFC(mSet, "fc_2_", "png", 72, width=NA)
mSet<-PlotCorrHeatMap(mSet, "corr_2_", "png", 72, width=NA, "col", "pearson", "bwm", "overview", F, F, "0")
mSet<-PlotCorrHeatMap(mSet, "corr_3_", "png", 72, width=NA, "col", "pearson", "gray", "overview", F, F, "0")
mSet<-PlotCorrHeatMap(mSet, "corr_4_", "png", 72, width=NA, "col", "pearson", "gray", "overview", T, F, "0")
